from __future__ import annotations

from typing import Any, Dict


def register(app, deps) -> None:
    """Register oil-change endpoints.

    Incremental refactor step: handlers live here, while core helpers remain in `deps`
    (provided by app_monolith) to avoid breaking changes.
    """

    def _ensure_capacity_label(cap_item: dict) -> dict:
        """Ensure capacity_label_with_filter is a non-empty string for Flutter contract."""
        out = dict(cap_item) if isinstance(cap_item, dict) else {}
        lbl = out.get("capacity_label_with_filter")

        if isinstance(lbl, str) and lbl.strip():
            return out

        # If variants exist, we can't pick one label reliably; communicate variability
        variants = out.get("variants")
        if isinstance(variants, list) and len(variants) > 0:
            out["capacity_label_with_filter"] = "Varies by configuration"
            return out

        q = out.get("capacity_quarts_with_filter")
        if isinstance(q, (int, float)):
            out["capacity_label_with_filter"] = f"{q:g} qt"
        else:
            out["capacity_label_with_filter"] = "Unknown capacity — check owner's manual"
        return out

    def _fallback_oil_spec(resolved_engine_code: str) -> Dict[str, Any]:
        return {
            "engine_code": resolved_engine_code,
            "label": "Unknown oil spec — check owner's manual",
            "viscosity": None,
            "standard": None,
            "verified": False,
            "warning": f"No oil spec coverage yet for {resolved_engine_code}.",
            "status": "MISSING",
        }

    def _fallback_oil_capacity(resolved_engine_code: str) -> Dict[str, Any]:
        return {
            "engine_code": resolved_engine_code,
            "capacity_quarts_with_filter": None,
            "capacity_label_with_filter": "Unknown capacity — check owner's manual",
            "verified": False,
            "warning": f"No oil capacity coverage yet for {resolved_engine_code}.",
            "status": "MISSING",
        }

    @app.get("/oil-change/by-engine")
    def oil_change_by_engine(
        engine_code: str,
        year: int | None = None,
        make: str | None = None,
        model: str | None = None,
        engine_label: str | None = None,
    ):
        """Return oil spec + capacity + filter info for a single engine code.

        Contract notes (Flutter):
          - oil_spec must be an object with a non-empty string field `label`
          - oil_capacity must be an object with a non-empty string field `capacity_label_with_filter`
        """
        _, _, oil_specs, oil_capacity, oil_parts, oil_filter_groups, _ = deps.reload_all()

        resolved_engine_code = deps.resolve_engine_code(
            engine_code,
            engine_label,
            year=year,
            make=make,
            model=model,
        )

        spec_item = deps._find_seed_item(oil_specs.get("items", []), resolved_engine_code)
        spec_item_resolved = deps.resolve_oil_spec_item(spec_item, oil_specs)

        cap_item = deps._find_seed_item(oil_capacity.get("items", []), resolved_engine_code)
        parts_item = deps._find_seed_item(oil_parts.get("items", []), resolved_engine_code)

        # --- Oil filter hydration (supports both legacy inline schema and v2 oil_filter_group schema) ---
        oil_filter: Dict[str, Any] = {}
        parts_item_out = parts_item
        if isinstance(parts_item, dict):
            # Prefer new schema: oil_filter_group -> lookup in oil_filter_groups.json
            group_key = parts_item.get("oil_filter_group")
            if isinstance(group_key, str) and group_key.strip() and isinstance(oil_filter_groups, dict):
                grp = oil_filter_groups.get(group_key.strip())
                if isinstance(grp, dict):
                    oil_filter = deps.json.loads(deps.json.dumps(grp))  # deep copy (avoid mutating loaded doc)
            # Fallback to legacy inline oil_filter blob
            if not oil_filter:
                legacy = parts_item.get("oil_filter")
                if isinstance(legacy, dict):
                    oil_filter = deps.json.loads(deps.json.dumps(legacy))

            # Attach hydrated filter back onto returned parts object (keeps Flutter happy)
            parts_item_out = dict(parts_item)
            if oil_filter:
                parts_item_out["oil_filter"] = oil_filter

        # Add buy links when we have filter data
        oem = oil_filter.get("oem")
        if isinstance(oem, dict):
            oem["buy_links"] = deps.build_buy_links(oem)
        alts = oil_filter.get("alternatives")
        if isinstance(alts, list):
            for alt in alts:
                if isinstance(alt, dict):
                    alt["buy_links"] = deps.build_buy_links(alt)

        # Contract-safe fallbacks to prevent Flutter crashes when seeds are missing
        oil_spec_out = spec_item_resolved if isinstance(spec_item_resolved, dict) else _fallback_oil_spec(resolved_engine_code)
        oil_capacity_out = _ensure_capacity_label(cap_item) if isinstance(cap_item, dict) else _fallback_oil_capacity(resolved_engine_code)

        return {
            "engine_code": engine_code,
            "resolved_engine_code": resolved_engine_code,
            "found": {
                "oil_spec": spec_item is not None,
                "oil_capacity": cap_item is not None,
                "oil_parts": parts_item is not None,
            },
            "oil_spec": oil_spec_out,
            "oil_capacity": oil_capacity_out,
            "oil_parts": parts_item_out,
        }

    @app.get("/oil-change/coverage/missing-engine-codes")
    def coverage():
        vehicles_doc, _, oil_specs, oil_capacity, oil_parts, _, _ = deps.reload_all()

        vehicle_codes = set()
        for v in vehicles_doc.get("vehicles", []):
            for ec in (v.get("engine_codes") or []):
                if ec:
                    vehicle_codes.add(ec)

        spec_codes = {deps.seed_to_raw(i.get("engine_code")) for i in oil_specs.get("items", []) if i.get("engine_code")}
        cap_codes = {deps.seed_to_raw(i.get("engine_code")) for i in oil_capacity.get("items", []) if i.get("engine_code")}
        part_codes = {deps.seed_to_raw(i.get("engine_code")) for i in oil_parts.get("items", []) if i.get("engine_code")}

        present = vehicle_codes & spec_codes & cap_codes & part_codes
        missing = vehicle_codes - present

        return {
            "vehicles_engine_codes": len(vehicle_codes),
            "oil_specs_engine_codes": len(spec_codes),
            "oil_capacity_engine_codes": len(cap_codes),
            "oil_parts_engine_codes": len(part_codes),
            "present_engine_codes": len(present),
            "missing_engine_codes": len(missing),
            "missing_engine_codes_list": sorted(missing),
        }
