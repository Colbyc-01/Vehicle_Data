from __future__ import annotations

from typing import Any, Dict, Optional
from fastapi import Body

def register(app, deps) -> None:
    """Register maintenance bundle endpoint.

    deps.maintenance_bundle must be a callable matching:
      (vehicle_id: str, year: int, engine_code: Optional[str]) -> dict
    """

    @app.get("/maintenance/bundle")
    def maintenance_bundle(vehicle_id: str, year: int, engine_code: Optional[str] = None):
        return deps.maintenance_bundle(vehicle_id=vehicle_id, year=year, engine_code=engine_code)
