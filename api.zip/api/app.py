from api import app_monolith
app = app_monolith.app
