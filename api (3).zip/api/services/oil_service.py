from __future__ import annotations

from typing import Any, Dict, Optional


def _ensure_capacity_label(cap_item: dict) -> dict:
    """Ensure capacity_label_with_filter is a non-empty string for Flutter contract."""
    out = dict(cap_item) if isinstance(cap_item, dict) else {}
    lbl = out.get("capacity_label_with_filter")

    if isinstance(lbl, str) and lbl.strip():
        return out

    variants = out.get("variants")
    if isinstance(variants, list) and len(variants) > 0:
        out["capacity_label_with_filter"] = "Varies by configuration"
        return out

    q = out.get("capacity_quarts_with_filter")
    if isinstance(q, (int, float)):
        out["capacity_label_with_filter"] = f"{q:g} qt"
    else:
        out["capacity_label_with_filter"] = "Unknown capacity — check owner's manual"
    return out


def _fallback_oil_spec(resolved_engine_code: str) -> Dict[str, Any]:
    return {
        "engine_code": resolved_engine_code,
        "label": "Unknown oil spec — check owner's manual",
        "viscosity": None,
        "standard": None,
        "verified": False,
        "warning": f"No oil spec coverage yet for {resolved_engine_code}.",
        "status": "MISSING",
    }


def _fallback_oil_capacity(resolved_engine_code: str) -> Dict[str, Any]:
    return {
        "engine_code": resolved_engine_code,
        "capacity_quarts_with_filter": None,
        "capacity_label_with_filter": "Unknown capacity — check owner's manual",
        "verified": False,
        "warning": f"No oil capacity coverage yet for {resolved_engine_code}.",
        "status": "MISSING",
    }


def oil_change_by_engine(
    deps,
    *,
    engine_code: str,
    year: Optional[int] = None,
    make: Optional[str] = None,
    model: Optional[str] = None,
    engine_label: Optional[str] = None,
) -> Dict[str, Any]:
    """Return oil spec + capacity + filter info for a single engine code."""

    _, _, oil_specs, oil_capacity, oil_parts, oil_filter_groups, _ = deps.reload_all()

    resolved_engine_code = deps.resolve_engine_code(
        engine_code,
        engine_label,
        year=year,
        make=make,
        model=model,
    )

    spec_item = deps._find_seed_item(oil_specs.get("items", []), resolved_engine_code)
    spec_item_resolved = deps.resolve_oil_spec_item(spec_item, oil_specs)

    cap_item = deps._find_seed_item(oil_capacity.get("items", []), resolved_engine_code)
    parts_item = deps._find_seed_item(oil_parts.get("items", []), resolved_engine_code)

    # --- Oil filter hydration (supports both legacy inline schema and v2 oil_filter_group schema) ---
    oil_filter: Dict[str, Any] = {}
    parts_item_out = parts_item
    if isinstance(parts_item, dict):
        group_key = parts_item.get("oil_filter_group")
        if isinstance(group_key, str) and group_key.strip() and isinstance(oil_filter_groups, dict):
            grp = oil_filter_groups.get(group_key.strip())
            if isinstance(grp, dict):
                oil_filter = deps.json.loads(deps.json.dumps(grp))  # deep copy
        if not oil_filter:
            legacy = parts_item.get("oil_filter")
            if isinstance(legacy, dict):
                oil_filter = deps.json.loads(deps.json.dumps(legacy))

        parts_item_out = dict(parts_item)
        if oil_filter:
            parts_item_out["oil_filter"] = oil_filter

    # Add buy links when we have filter data
    oem = oil_filter.get("oem")
    if isinstance(oem, dict):
        oem["buy_links"] = deps.build_buy_links(oem)
    alts = oil_filter.get("alternatives")
    if isinstance(alts, list):
        for alt in alts:
            if isinstance(alt, dict):
                alt["buy_links"] = deps.build_buy_links(alt)

    oil_spec_out = spec_item_resolved if isinstance(spec_item_resolved, dict) else _fallback_oil_spec(resolved_engine_code)
    oil_capacity_out = _ensure_capacity_label(cap_item) if isinstance(cap_item, dict) else _fallback_oil_capacity(resolved_engine_code)

    return {
        "engine_code": resolved_engine_code,
        "oil_spec": oil_spec_out,
        "oil_capacity": oil_capacity_out,
        "oil_change_parts": parts_item_out or {},
    }
