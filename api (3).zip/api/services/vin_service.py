from __future__ import annotations

from typing import Any, Dict


def resolve(deps, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Resolve a VIN into a canonical vehicle and (when possible) a single engine.

    `deps` is a narrow dependency surface provided by `api.core.legacy_deps` for now.
    """

    vin = str(payload.get("vin", "")).strip().upper()
    seed_version = payload.get("seed_version")
    app_version = payload.get("app_version")

    if not vin:
        return {"status": "ERROR", "error": "VIN_REQUIRED"}

    vin_hash = deps._vin_hash(vin)

    decoded = deps._nhtsa_decode_vin(vin)
    if not decoded.get("ok"):
        return {"status": "ERROR", "error": decoded.get("error", "DECODE_FAILED")}

    year = decoded.get("year")
    make = decoded.get("make")
    model = decoded.get("model")

    signature = deps._signature_for(decoded)

    # Can't even get year/make/model -> unsupported
    if not (year and make and model):
        deps._sqlite_upsert_rollup(signature, decoded, "UNSUPPORTED", seed_version, app_version)
        return {
            "status": "UNSUPPORTED",
            "vin_hash": vin_hash,
            "decoded": {
                "year": year,
                "make": make,
                "model": model,
                "trim": decoded.get("trim"),
                "engine": decoded.get("engine"),
                "engine_displacement_l": decoded.get("engine_displacement_l"),
                "engine_cylinders": decoded.get("engine_cylinders"),
                "fuel_type": decoded.get("fuel_type"),
            },
        }

    # 1) Exact match
    matches = deps._search_impl(year, make, model)

    # 2) Fuzzy match (punctuation + family models)
    if not matches:
        matches = deps._fuzzy_model_candidates(year, make, model)

    if not matches:
        deps._sqlite_upsert_rollup(signature, decoded, "UNSUPPORTED", seed_version, app_version)
        return {
            "status": "UNSUPPORTED",
            "vin_hash": vin_hash,
            "decoded": {
                "year": year,
                "make": make,
                "model": model,
                "trim": decoded.get("trim"),
                "engine": decoded.get("engine"),
                "engine_displacement_l": decoded.get("engine_displacement_l"),
                "engine_cylinders": decoded.get("engine_cylinders"),
                "fuel_type": decoded.get("fuel_type"),
            },
        }

    # If multiple possible canonical vehicles, try to auto-pick using VIN engine hints; otherwise ask user to choose.
    if len(matches) > 1:
        # --- AUTO-PICK best vehicle match using VIN engine hints (GLOBAL) ---
        hint_disp = decoded.get("engine_displacement_l")
        hint_engine_model = decoded.get("engine")  # e.g., "L59"

        # 1) If VIN gave an engine model, try map -> canonical engine code and pick a vehicle that contains it.
        hint_engine_code = None
        if hint_engine_model:
            hint_engine_code = deps.resolve_engine_code(
                hint_engine_model,
                None,
                year=year,
                make=make,
                model=model,
            )

        if hint_engine_code:
            by_engine_code = []
            for v in matches:
                if not isinstance(v, dict):
                    continue
                lbl = v.get("engine_label")
                v_eng = [
                    deps.resolve_engine_code(c, lbl, year=year, make=v.get("make"), model=v.get("model"))
                    for c in (v.get("engine_codes") or [])
                    if c
                ]
                if hint_engine_code in v_eng:
                    by_engine_code.append(v)
            if len(by_engine_code) == 1:
                matches = by_engine_code

        # 2) If still multiple, use displacement vs engine_label (e.g., 5.3 matches "5.3L V8")
        if len(matches) > 1 and hint_disp:
            disp_str = str(hint_disp)
            by_disp = [v for v in matches if isinstance(v, dict) and disp_str in str(v.get("engine_label", ""))]
            if len(by_disp) == 1:
                matches = by_disp
        # --- END AUTO-PICK ---

    # If still multiple possible canonical vehicles, ask user to choose (keep list short)
    if len(matches) > 1:
        deps._sqlite_upsert_rollup(signature, decoded, "AMBIGUOUS", seed_version, app_version)
        engines_doc = deps.load_json(deps.DATA / "engines.json")
        candidates = []
        for v in matches[:8]:
            if not isinstance(v, dict):
                continue
            # Normalize engine codes for downstream seed lookups
            lbl = v.get("engine_label")
            v_eng = [
                deps.resolve_engine_code(c, lbl, year=year, make=v.get("make"), model=v.get("model"))
                for c in (v.get("engine_codes") or [])
                if c
            ]
            candidates.append(
                {
                    "vehicle_id": v.get("vehicle_id"),
                    "make": v.get("make"),
                    "model": v.get("model"),
                    "year_min": v.get("year_min"),
                    "year_max": v.get("year_max"),
                    "engine_label": v.get("engine_label"),
                    "engine_codes": v_eng,
                    "engine_names": [
                        deps.engine_display_name(ec, vehicle_engine_label=v.get("engine_label"), engines_doc=engines_doc)
                        for ec in v_eng
                    ],
                }
            )
        return {
            "status": "AMBIGUOUS",
            "vin_hash": vin_hash,
            "decoded": {
                "year": year,
                "make": make,
                "model": model,
                "trim": decoded.get("trim"),
                "engine": decoded.get("engine"),
                "engine_displacement_l": decoded.get("engine_displacement_l"),
                "engine_cylinders": decoded.get("engine_cylinders"),
                "fuel_type": decoded.get("fuel_type"),
            },
            "vehicle_candidates": deps._dedupe_candidates(candidates, year=decoded.get("year") if isinstance(decoded, dict) else None),
        }

    vehicle = matches[0]

    # Normalize engine codes to canonical codes so seeds can be queried reliably.
    lbl = vehicle.get("engine_label") if isinstance(vehicle, dict) else None
    engine_codes = [
        deps.resolve_engine_code(
            c,
            lbl,
            year=year,
            make=vehicle.get("make") if isinstance(vehicle, dict) else None,
            model=vehicle.get("model") if isinstance(vehicle, dict) else None,
        )
        for c in ((vehicle.get("engine_codes") or []) if isinstance(vehicle, dict) else [])
        if c
    ]

    engines_doc = deps.load_json(deps.DATA / "engines.json")

    # --- Prefer explicit VIN EngineModel (e.g., "L59") when it maps to a canonical code we support ---
    engine_code = None
    raw_engine_model = decoded.get("engine")
    if raw_engine_model:
        model_hint = deps.resolve_engine_code(
            raw_engine_model,
            lbl,
            year=year,
            make=vehicle.get("make") if isinstance(vehicle, dict) else None,
            model=vehicle.get("model") if isinstance(vehicle, dict) else None,
        )
        if model_hint in engine_codes:
            engine_code = model_hint

    # If not set yet, try to auto-select an engine if VIN decode gives strong hints.
    if engine_code is None:
        hint_disp = decoded.get("engine_displacement_l")
        hint_cyl = decoded.get("engine_cylinders")
        hint_fuel = deps.norm(decoded.get("fuel_type"))

        def _engine_score(code: str) -> int:
            e = engines_doc.get(code) or {}
            score = 0
            if hint_disp is not None and isinstance(e.get("displacement_l"), (int, float)):
                if abs(float(e["displacement_l"]) - float(hint_disp)) <= 0.15:
                    score += 10
            if hint_cyl is not None and deps.as_int(e.get("cylinders")) == hint_cyl:
                score += 7
            if hint_fuel and deps.norm(e.get("fuel_type")) == hint_fuel:
                score += 4
            return score

        if len(engine_codes) == 1:
            engine_code = engine_codes[0]
        elif len(engine_codes) > 1:
            scored = [(_engine_score(c), c) for c in engine_codes]
            scored.sort(reverse=True)
            # Only auto-pick if it's clearly better than the rest
            if scored and scored[0][0] >= 10 and (len(scored) == 1 or scored[0][0] >= scored[1][0] + 5):
                engine_code = scored[0][1]

    # If still ambiguous, return engine choices (with friendly names)
    if len(engine_codes) > 1 and engine_code is None:
        deps._sqlite_upsert_rollup(signature, decoded, "AMBIGUOUS", seed_version, app_version)
        engine_choices = []
        for c in engine_codes:
            e = engines_doc.get(c) or {}
            engine_choices.append(
                {
                    "engine_code": c,
                    "engine_name": deps.engine_display_name(
                        c,
                        vehicle_engine_label=vehicle.get("engine_label") if isinstance(vehicle, dict) else None,
                        engines_doc=engines_doc,
                    ),
                    "displacement_l": e.get("displacement_l"),
                    "cylinders": e.get("cylinders"),
                    "fuel_type": e.get("fuel_type"),
                }
            )
        return {
            "status": "AMBIGUOUS",
            "vin_hash": vin_hash,
            "decoded": {
                "year": year,
                "make": make,
                "model": model,
                "trim": decoded.get("trim"),
                "engine": decoded.get("engine"),
                "engine_displacement_l": decoded.get("engine_displacement_l"),
                "engine_cylinders": decoded.get("engine_cylinders"),
                "fuel_type": decoded.get("fuel_type"),
            },
            "vehicle": {
                "vehicle_id": vehicle.get("vehicle_id"),
                "make": vehicle.get("make"),
                "model": vehicle.get("model"),
                "year_min": vehicle.get("year_min"),
                "year_max": vehicle.get("year_max"),
                "engine_label": vehicle.get("engine_label"),
                "engine_codes": engine_codes,
            },
            "engine_choices": engine_choices,
        }

    deps._sqlite_upsert_rollup(signature, decoded, "RESOLVED", seed_version, app_version)

    return {
        "status": "RESOLVED",
        "vin_hash": vin_hash,
        "decoded": {
            "year": year,
            "make": make,
            "model": model,
            "trim": decoded.get("trim"),
            "engine": decoded.get("engine"),
            "engine_displacement_l": decoded.get("engine_displacement_l"),
            "engine_cylinders": decoded.get("engine_cylinders"),
            "fuel_type": decoded.get("fuel_type"),
        },
        "vehicle": {
            "vehicle_id": vehicle.get("vehicle_id"),
            "make": vehicle.get("make"),
            "model": vehicle.get("model"),
            "year_min": vehicle.get("year_min"),
            "year_max": vehicle.get("year_max"),
            "engine_label": vehicle.get("engine_label"),
            "engine_codes": engine_codes,
        },
        "engine_code": engine_code,
    }


def resolve_and_bundle(deps, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Convenience: resolve VIN and return maintenance bundle when possible."""
    vin_result = resolve(deps, payload)
    status = vin_result.get("status")

    if status == "RESOLVED":
        vehicle = vin_result.get("vehicle") or {}
        decoded = vin_result.get("decoded") or {}
        engine_code = vin_result.get("engine_code")
        vehicle_id = vehicle.get("vehicle_id")
        year = decoded.get("year")
        bundle = deps.maintenance_bundle(vehicle_id=vehicle_id, year=year, engine_code=engine_code)
        _, engines_doc, _, _, _, _, _ = deps.reload_all()
        engine_name = deps.engine_display_name(
            engine_code,
            vehicle_engine_label=vehicle.get("engine_label"),
            engines_doc=engines_doc,
        )
        return {
            "status": "READY",
            "vin_hash": vin_result.get("vin_hash"),
            "decoded": decoded,
            "vehicle": vehicle,
            "engine_code": engine_code,
            "engine_name": engine_name,
            "bundle": bundle,
        }

    if status == "AMBIGUOUS":
        if vin_result.get("vehicle_candidates"):
            return {
                "status": "NEEDS_VEHICLE_CONFIRMATION",
                "vin_hash": vin_result.get("vin_hash"),
                "decoded": vin_result.get("decoded"),
                "vehicle_candidates": vin_result.get("vehicle_candidates"),
            }
        return {
            "status": "NEEDS_ENGINE_CONFIRMATION",
            "vin_hash": vin_result.get("vin_hash"),
            "decoded": vin_result.get("decoded"),
            "vehicle": vin_result.get("vehicle"),
            "engine_choices": vin_result.get("engine_choices"),
            "bundle": None,
        }

    return {
        "status": status,
        "vin_hash": vin_result.get("vin_hash"),
        "decoded": vin_result.get("decoded"),
        "error": vin_result.get("error"),
        "bundle": None,
    }
