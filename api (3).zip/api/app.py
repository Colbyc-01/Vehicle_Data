"""FastAPI application entrypoint.

Goal: keep the HTTP surface clean and modular (routes + services), while we
progressively migrate logic out of the legacy monolith.

Today, we still *adapt* a small set of legacy functions for parity testing.
Once each service is migrated, we remove the legacy adapter and delete the
monolith.
"""

from __future__ import annotations

from fastapi import FastAPI

from api.routes import maintenance as maintenance_routes
from api.routes import manual as manual_routes
from api.routes import oil_change as oil_routes
from api.routes import vin as vin_routes

from api.core.legacy_deps import build_legacy_deps


def create_app() -> FastAPI:
    app = FastAPI(title="Vehicle Data API")

    # --- Dependencies ---
    # Temporary: provide the same callable surface as app_monolith exposed,
    # but via a single, well-defined adapter.
    deps = build_legacy_deps()

    # --- Modular routes ---
    manual_routes.register(app, deps)
    vin_routes.register(app, deps)
    oil_routes.register(app, deps)
    app.include_router(maintenance_routes.build_router(deps))

    return app


app = create_app()
