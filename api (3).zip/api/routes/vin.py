from __future__ import annotations

from typing import Any, Dict

from fastapi import Body

from api.services import vin_service

def register(app, deps) -> None:
    """Register VIN-related endpoints on the provided FastAPI app.

    This is an incremental refactor step: handlers live here, while core helpers
    (VIN decoding, matching, persistence, bundle building) remain in deps for now.
    """

    @app.post("/vin/resolve_and_bundle")
    def vin_resolve_and_bundle(payload: Dict[str, Any] = Body(...)):
        return vin_service.resolve_and_bundle(deps, payload)

    @app.post("/vin/resolve")
    def vin_resolve(payload: Dict[str, Any] = Body(...)):
        return vin_service.resolve(deps, payload)
