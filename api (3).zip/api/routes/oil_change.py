from __future__ import annotations

from typing import Optional

from api.services import oil_service


def register(app, deps) -> None:
    """Register oil-change endpoints.

    Route stays thin; logic lives in `api.services.oil_service`.
    """

    @app.get("/oil-change/by-engine")
    def oil_change_by_engine(
        engine_code: str,
        year: Optional[int] = None,
        make: Optional[str] = None,
        model: Optional[str] = None,
        engine_label: Optional[str] = None,
    ):
        return oil_service.oil_change_by_engine(
            deps,
            engine_code=engine_code,
            year=year,
            make=make,
            model=model,
            engine_label=engine_label,
        )
