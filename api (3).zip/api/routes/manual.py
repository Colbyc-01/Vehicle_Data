from __future__ import annotations

from typing import Any, Dict
from fastapi import Body

def register(app, deps) -> None:
    """Register manual-selection endpoints (years/makes/models/search).

    Incremental refactor step: handlers live here, while core helpers remain in `deps`
    (provided by app_monolith) to avoid breaking changes.
    """

    @app.get("/years")
    def get_years():
        vehicles_doc, *_ = deps.reload_all()
        years = set()
        for v in vehicles_doc.get("vehicles", []):
            y0 = v.get("year_min")
            y1 = v.get("year_max")
            if isinstance(y0, int) and isinstance(y1, int):
                years.update(range(y0, y1 + 1))
        return sorted(years)

    @app.get("/makes")
    def get_makes(year: int):
        vehicles_doc, *_ = deps.reload_all()

        makes = set()
        for v in vehicles_doc.get("vehicles", []):
            y0 = deps.as_int(v.get("year_min"))
            y1 = deps.as_int(v.get("year_max"))

            if y0 is None or y1 is None:
                continue

            if y0 <= year <= y1:
                m = v.get("make")
                if m:
                    makes.add(m)

        return sorted(makes)

    @app.get("/models")
    def get_models(year: int, make: str):
        vehicles_doc, *_ = deps.reload_all()
        make_n = deps.norm(make)

        models = set()
        for v in vehicles_doc.get("vehicles", []):
            y0 = deps.as_int(v.get("year_min"))
            y1 = deps.as_int(v.get("year_max"))
            if y0 is None or y1 is None:
                continue

            if y0 <= year <= y1 and deps.norm(v.get("make")) == make_n:
                md = v.get("model")
                if md:
                    models.add(md)

        return sorted(models)

    @app.get("/vehicles/search")
    def vehicles_search(year: int, make: str, model: str):
        matches = deps._search_impl(year, make, model)

        # Normalize engine codes to canonical codes so oil seeds can be queried reliably.
        for v in matches:
            if not isinstance(v, dict):
                continue
            lbl = v.get("engine_label")
            v["engine_codes"] = [
                deps.resolve_engine_code(
                    c,
                    lbl,
                    year=year,
                    make=v.get("make"),
                    model=v.get("model"),
                )
                for c in (v.get("engine_codes") or [])
                if c
            ]

        vehicle0 = matches[0] if matches else None
        return {
            "query": {"year": year, "make": make, "model": model},
            "count": len(matches),
            "results": matches,
            "vehicles": matches,
            "vehicle": vehicle0,
        }
