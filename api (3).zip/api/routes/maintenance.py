from __future__ import annotations

from typing import Optional

from fastapi import APIRouter

from api.services.maintenance_service import build_maintenance_bundle


def build_router(deps) -> APIRouter:
    """Build the maintenance router using the provided dependencies."""

    router = APIRouter()

    @router.get("/maintenance/bundle")
    def maintenance_bundle(vehicle_id: str, year: int, engine_code: Optional[str] = None):
        return build_maintenance_bundle(
            deps=deps,
            vehicle_id=vehicle_id,
            year=year,
            engine_code=engine_code,
        )

    return router
