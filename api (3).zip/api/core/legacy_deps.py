"""Legacy dependency adapter.

This is the *only* place in the modularized codebase allowed to import
`app_monolith`.

Routes/services should depend on a `deps` object that exposes the specific
functions they need. As we migrate functionality out of the monolith into
`api.services`, we replace implementations here until it can be deleted.
"""

from __future__ import annotations

from types import SimpleNamespace


def build_legacy_deps():
    # Local import to keep the module import graph clean.
    from api import app_monolith  # type: ignore

    # Expose ONLY what modular routes currently expect.
    deps = SimpleNamespace(
        # Core data refresh + helpers
        reload_all=app_monolith.reload_all,
        load_json=app_monolith.load_json,
        DATA=app_monolith.DATA,
        norm=app_monolith.norm,
        as_int=app_monolith.as_int,

        # VIN + matching internals used by routes/vin.py & routes/manual.py
        _vin_hash=app_monolith._vin_hash,
        _nhtsa_decode_vin=app_monolith._nhtsa_decode_vin,
        _signature_for=app_monolith._signature_for,
        _search_impl=app_monolith._search_impl,
        _fuzzy_model_candidates=app_monolith._fuzzy_model_candidates,
        _dedupe_candidates=app_monolith._dedupe_candidates,
        resolve_engine_code=app_monolith.resolve_engine_code,
        engine_display_name=app_monolith.engine_display_name,
        _sqlite_upsert_rollup=app_monolith._sqlite_upsert_rollup,

        # Oil-change helpers used by routes/oil_change.py
        _find_seed_item=app_monolith._find_seed_item,
        resolve_oil_spec_item=app_monolith.resolve_oil_spec_item,
        json=app_monolith.json,
        build_buy_links=app_monolith.build_buy_links,
    )

    # Prefer the modular maintenance service over the monolith.
    # Keep the callable signature the same for any callers that still expect it.
    from api.services.maintenance_service import build_maintenance_bundle

    def _maintenance_bundle(vehicle_id: str, year: int, engine_code=None):
        return build_maintenance_bundle(
            deps=deps,
            vehicle_id=vehicle_id,
            year=year,
            engine_code=engine_code,
        )

    deps.maintenance_bundle = _maintenance_bundle

    return deps
