"""Centralized filesystem paths used by the API.

This wraps the existing `api.data.paths` module so we can transition imports
without breaking current behavior.
"""

from __future__ import annotations

from api.data.paths import *  # noqa: F403
