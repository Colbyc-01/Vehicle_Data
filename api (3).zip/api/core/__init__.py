"""Core configuration and dependency wiring."""
