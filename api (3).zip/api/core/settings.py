"""Application settings.

Keep this intentionally lightweight for now (no new dependencies). If you later
want pydantic-settings, we can swap it in without touching route/service code.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    env: str = os.getenv("ENV", "dev")
    cors_allow_origins: str = os.getenv("CORS_ALLOW_ORIGINS", "*")


settings = Settings()
